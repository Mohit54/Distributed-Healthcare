from django.urls import path
from . import views
from articles.views import ArticleDetailView
from .views import SearchResultsView
from django.views.generic import ListView, DetailView
urlpatterns = [
path('', views.ArticleListView.as_view(), name='article_list'),
path('<int:pk>/edit/',
views.ArticleUpdateView.as_view(), name='article_edit'), # new

path('<int:pk>/',
views.ArticleDetailView.as_view(), name='article_detail'), # new


path('<int:pk>/',
views.ArticleDeleteView.as_view(), name='article_delete'), # new
path('new/', views.ArticleCreateView.as_view(), name='article_new'),
path('search/', SearchResultsView.as_view(), name='search_results'),

]