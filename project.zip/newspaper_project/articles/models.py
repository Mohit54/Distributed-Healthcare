from django.db import models

# Create your models here.
from django.conf import settings
from django.db import models
from django.urls import reverse
from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField

from django.core.exceptions import ValidationError

def validate_length(value,length=6):
    if len(str(value))<=length:
        raise ValidationError(u'%s is not the correct length, Username must contain minimum 7 characters' % value)



class Article(models.Model):
	title = models.CharField(max_length=255, blank=False, unique=True, help_text='Eg. Machine Learning',error_messages ={ 
                    'unique':"The Title you entered is not unique."
                    })

	technology_type = models.CharField(max_length=255, blank=False, help_text='Eg.Software,Hardware, Web, Database, AI, Other')

	content = RichTextField(blank=False,help_text='Eg. Links or Actual data')

	summary = RichTextUploadingField(blank=False, help_text='Eg. Conclusion')

	date = models.DateTimeField(auto_now_add=True)

	author = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,)

	
	def __str__(self):
		return self.title
	def get_absolute_url(self):
		return reverse('article_detail', args=[str(self.id)])

	class Meta:
           ordering = ['-date',]

class Foo(models.Model):
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)



class Patient(models.Model):
	name = models.CharField(max_length=255, blank=False)

	age = models.PositiveIntegerField(default=0)

	phone = models.CharField(max_length=255, blank=False)

	

	date = models.DateTimeField(auto_now_add=True)

	GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),)
	gender = models.CharField(max_length=1, choices=GENDER_CHOICES)

	BLOOD_CHOICES = (
        ('A+', 'A +'),
        ('B+', 'B +'),)
	blood_group = models.CharField(max_length=2, choices=BLOOD_CHOICES)
	photo = models.ImageField()


class Comment(models.Model):
	article = models.ForeignKey(Article, on_delete=models.CASCADE)
	comment = models.CharField(max_length=140)
	author = models.ForeignKey(
	settings.AUTH_USER_MODEL,
	on_delete=models.CASCADE,
	)
	def __str__(self):
		return self.comment
	def get_absolute_url(self):
		return reverse('article_list')