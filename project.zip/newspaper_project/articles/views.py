from django.shortcuts import render

# Create your views here.
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from . import models
from articles.models import Article
from .models import Article
from django.http import HttpResponse
from django.db.models import Q
from django.contrib.auth.models import User
from django.views.generic.base import TemplateView
from django.contrib.auth.models import User
from django.shortcuts import render
# from .filters import UserFilter
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger



class SearchResultsView(ListView):
    model = models.Article
    template_name = 'search_results.html'
    def get_queryset(self):
        query = self.request.GET.get('q')

        if query:
           object_list = Article.objects.filter(Q(technology_type__icontains=query) | Q(title__icontains=query) | Q(summary__icontains=query) | Q(content__icontains=query))
           return object_list

		
        else:
           result = None    # When no result found

        return result






from django.views.generic import TemplateView
class HomePageView(TemplateView):
	template_name = 'home.html'













class ArticleListView(LoginRequiredMixin, ListView):

	model = models.Article
	paginate_by = 10
	template_name = 'article_list.html'
	login_url = 'login'
class ArticleDetailView(LoginRequiredMixin, DetailView):
	model = models.Article
	template_name = 'article_detail.html'
	login_url = 'login'



class ArticleUpdateView(LoginRequiredMixin, UpdateView):
	model = models.Article
	fields = ['title', 'technology_type','content','summary', ]
	template_name = 'article_edit.html'
	success_url = reverse_lazy('article_list')
	login_url = 'login'
	def get_queryset(self):
            queryset = super(ArticleUpdateView, self).get_queryset()
            queryset = queryset.filter(author=self.request.user)
            return queryset

class ArticleDeleteView(LoginRequiredMixin, DeleteView):
	model = models.Article
	template_name = 'article_delete.html'
	success_url = reverse_lazy('article_list')
	login_url = 'login'


class ArticleCreateView(LoginRequiredMixin, CreateView):
	model = models.Article
	template_name = 'article_new.html'
	fields = ['title', 'technology_type','content','summary', ]
	success_url = reverse_lazy('article_list')
	login_url = 'login'


	def form_valid(self, form):
		form.instance.author = self.request.user
		return super().form_valid(form)
	
	
		