CKEDITOR.plugins.setLang( 'html5video', 'fr', {
    button: 'Insérer un lecteur video HTML5',
    title: 'HTML5 video',
    infoLabel: 'Informations video',
    allowed: 'Extensions de fichiers autorisées: MP4, WebM, Ogv',
    urlMissing: 'URL de la source video manquante. Veuillez la renseigner.',
    videoProperties: 'Propriétés Video',
    upload: 'Télécharger',
    btnUpload: 'Envoyer vers le serveur',
    advanced: 'Avancé',
    autoplay: 'Jouer automatiquement ?',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'Oui',
    no: 'Non',
    controls: 'Afficher les contrôles ?'
} );
